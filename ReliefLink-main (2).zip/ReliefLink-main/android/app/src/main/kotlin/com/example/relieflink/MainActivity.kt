package com.example.relieflink

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
