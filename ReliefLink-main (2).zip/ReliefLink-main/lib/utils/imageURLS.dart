Map<String, String> imageUrls = {
  "Muscle Relaxation": "assets/relaxationimage.png",
  "Take a walk": "assets/relaxationimage.png",
  "Talk to someone": "assets/relaxationimage.png",
  "Exercise": "assets/relaxationimage.png",
  "Meditate": "assets/relaxationimage.png",
  "Guided Imagery": "assets/relaxationimage.png",
  "Listen to Music": "assets/relaxationimage.png",
  "Watch a Movie": "assets/relaxationimage.png",
  "Volunteer": "assets/relaxationimage.png",
  "Be in Nature": "assets/relaxationimage.png",
  "Artistic Activities": "assets/relaxationimage.png",
  "Read a book": "assets/relaxationimage.png",
  "Intentional Breathing": "assets/relaxationimage.png",
  "Cold Shower": "assets/relaxationimage.png"
};